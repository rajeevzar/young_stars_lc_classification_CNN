import numpy as np
import matplotlib.pyplot as plt
from gtda.time_series import TakensEmbedding
from gtda.homology import VietorisRipsPersistence
from gtda.plotting import plot_diagram
from hurst import compute_Hc

# Step 1: Generate a synthetic time series (sine wave with noise)
np.random.seed(42)
time, time_series = np.loadtxt('EPIC246989752.dat', unpack = True)

valid_mask = ~np.isnan(time) & ~np.isnan(time_series)
time = time[valid_mask]
time_series = time_series[valid_mask]

# Normalize to have a mean of 0 and standard deviation of 1
time_series = (time_series - np.mean(time_series)) / np.std(time_series)

mask_five_sigma = (time_series <= 5) & (time_series >=-5)

time = time[mask_five_sigma]
time_series = time_series[mask_five_sigma]

time_series_hurst = time_series - np.min(time_series) + 1

H, c, _ = compute_Hc(time_series_hurst, kind='price')
print(f"Hurst Exponent: {H}")  # Measures how random an lc is: H < 0.5: Mean revertion, H=0.5: random(stochastic), H > 0.5: long-term trends

# Plot the time series
plt.figure(figsize=(8, 4))
plt.plot(time, time_series, label="Time Series")
plt.xlabel("Time")
plt.ylabel("Amplitude")
plt.title("Synthetic Time Series")
plt.legend()
plt.show()

# Step 2: Apply Takens embedding to reconstruct phase space
embedding = TakensEmbedding(time_delay=2, dimension=3)
embedded_time_series = embedding.fit_transform(time_series.reshape(1, -1))

# Visualize the embedded time series in 3D
from mpl_toolkits.mplot3d import Axes3D

fig = plt.figure(figsize=(8, 6))
ax = fig.add_subplot(111, projection="3d")
ax.plot(
    embedded_time_series[0, :, 0],
    embedded_time_series[0, :, 1],
    embedded_time_series[0, :, 2],
    lw=0.5,
)
ax.set_title("3D Takens Embedding")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
plt.show()

# # Step 3: Compute persistence diagram using Vietoris-Rips complex
# persistence = VietorisRipsPersistence(homology_dimensions=(0, 1, 2))
# diagrams = persistence.fit_transform(embedded_time_series)

# # Plot the persistence diagram
# plot_diagram(diagrams[0])
# plt.title("Persistence Diagram")  # Add title with matplotlib
# plt.show()

# # Step 4: Interpret the persistence diagram
# print("The persistence diagram shows the topological features of the embedded space.")
# print("Features close to the diagonal have low persistence (noise), while those far from it are significant.")
