#!/bin/bash

# Define the destination directory
DESTINATION="/path/to/destination"

# List of star folders to copy
STARS=(
    "EPIC210865655"
    "EPIC211104793"
    "EPIC247986526"
    "EPIC210690598"
    "EPIC210699670"
    "EPIC247810751"
    "EPIC247585465"
    "EPIC247788960"
    "EPIC247789209"
    "EPIC247046059"
    "EPIC248009353"
    "EPIC247027353"
    "EPIC247047380"
    "EPIC247584113"
    "EPIC246963876"
    "EPIC247592919"
    "EPIC248051303"
    "EPIC248049475"
    "EPIC246990243"
    "EPIC248029954"
    "EPIC248038058"
    "EPIC247941930"
    "EPIC246925324"
    "EPIC246923113"
    "EPIC247715356"
)

# Iterate over the star list and copy each folder
for STAR in "${STARS[@]}"; do
    if [ -d "$STAR" ]; then
        echo "Copying $STAR to $DESTINATION"
        cp -r "$STAR" "$DESTINATION"
    else
        echo "Warning: Directory $STAR does not exist!"
    fi
done

echo "Copy process completed."

