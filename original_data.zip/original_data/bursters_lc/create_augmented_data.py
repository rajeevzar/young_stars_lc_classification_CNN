# import os
# import numpy as np
# import importlib
# import augment_func
# importlib.reload(augment_func)
# from augment_func import augment 

# data_dir = "./"
# output_dir = "./augmented_data"

# os.makedirs(output_dir, exist_ok=True)  # Create the directory if it doesn't exist

# # Iterate through all dataset files in the directory
# for file_name in os.listdir(data_dir):
#     if file_name.endswith(".dat"):
#         # Load the original data
#         file_path = os.path.join(data_dir, file_name)
#         time_series = np.loadtxt(file_path)

#         # Apply augmentations and get the augmentation name
#         augmented_series, augmentation_name = augment(time_series)

#         # Print the augmentation name
#         print(f"Augmentation applied to {file_name}: {augmentation_name}")

#         # Save the augmented files to the output directory
#         output_path = os.path.join(output_dir, f"augmented_{file_name}")
#         np.savetxt(output_path, augmented_series, fmt="%.6f")
#         print(f"Augmented data saved to {output_path}")
#########################################The Above code is one augmentation per one file, below is for N augmentations ###########################################################


import os
import numpy as np
import importlib
import augment_func
importlib.reload(augment_func)
from augment_func import augment
import signal
import gc  # Garbage collection

# Define directories
data_dir = "./"
output_dir = "./augmented_data"
os.makedirs(output_dir, exist_ok=True)  # Create output directory if it doesn't exist

num_augmentations = 1000  # Total number of augmented light curves
timeout_seconds = 5  # Maximum time to wait for augmentation before skipping

# Function to handle timeout
def handler(signum, frame):
    raise TimeoutError("Augmentation took too long and was skipped.")

# Set the signal handler for timeouts
signal.signal(signal.SIGALRM, handler)

# Iterate through all dataset files in the directory
file_list = [f for f in os.listdir(data_dir) if f.endswith(".dat")]

if not file_list:
    print("No .dat files found in the directory.")

# Distribute augmentations across all files
for i in range(num_augmentations):
    file_name = np.random.choice(file_list)  # Randomly select a file from the dataset
    
    # Load the original data
    file_path = os.path.join(data_dir, file_name)
    time_series = np.loadtxt(file_path)

    success = False  # Flag to track if augmentation was successful

    try:
        signal.alarm(timeout_seconds)  # Start timeout timer

        # Apply augmentation
        augmented_series, augmentation_name = augment(time_series)
        
        # Cancel the alarm if augmentation completes successfully
        signal.alarm(0)
        success = True

    except TimeoutError:
        print(f"Augmentation for {file_name} took too long and was skipped.")
    
    except Exception as e:
        print(f"Error applying augmentation to {file_name}: {e}")

    if success:
        # Save each augmented light curve with a unique filename
        output_filename = f"augmented_{i+1:04d}_{file_name}"  # Unique numbering
        output_path = os.path.join(output_dir, output_filename)
        np.savetxt(output_path, augmented_series, fmt="%.6f")

        print(f"{i+1}/{num_augmentations} - {augmentation_name} applied to {file_name}, saved as {output_filename}")

    # Manually trigger garbage collection to free memory
    del time_series, augmented_series
    gc.collect()

