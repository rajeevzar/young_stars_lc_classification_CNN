import numpy as np
from scipy.interpolate import interp1d
from scipy.linalg import toeplitz
import random

# Helper function to extract time and values from the series
def extract_time_and_values(series):
    time = series[:, 0]
    values = series[:, 1]
    return time, values

# Augmentation functions
def time_warp(series, sigma=None):
    time, values = extract_time_and_values(series)
    n = len(values)
    time_steps = np.arange(n)
    random_factors = np.random.normal(1.0, sigma, size=n)
    warped_time_steps = np.cumsum(random_factors)
    warped_time_steps /= warped_time_steps[-1]  # Normalize to [0, 1]
    interpolator = interp1d(warped_time_steps, values, kind="linear", fill_value="extrapolate")
    warped_values = interpolator(time_steps / len(values))
    return np.column_stack((time, warped_values))

def jitter(series, sigma=None):
    time, values = extract_time_and_values(series)
    noisy_values = values + np.random.normal(0, sigma, size=len(values))
    return np.column_stack((time, noisy_values))

# def time_shift(series, max_shift=5):
#     shift = np.random.randint(-max_shift, max_shift)
#     shifted_series = np.roll(series, shift, axis=0)  # Shift both time and values
#     return shifted_series

def magnitude_scale(series, sigma=None):
    time, values = extract_time_and_values(series)
    factor = np.random.normal(1.0, sigma)
    scaled_values = values * factor
    return np.column_stack((time, scaled_values))

def perturb_fourier(series, sigma=None):
    time, values = extract_time_and_values(series)
    fft = np.fft.fft(values)
    random_phases = np.exp(1j * np.random.normal(0, sigma, size=len(fft)))
    perturbed_fft = fft * random_phases
    perturbed_values = np.real(np.fft.ifft(perturbed_fft))
    return np.column_stack((time, perturbed_values))

def add_correlated_noise(series, correlation_scale=0.1, noise_strength=None):
    time, values = extract_time_and_values(series)
    n = len(values)
    time_steps = np.arange(n)
    correlation_matrix = toeplitz(np.exp(-np.abs(time_steps) / (correlation_scale * n)))
    white_noise = np.random.normal(0, noise_strength, size=n)
    correlated_noise = np.dot(correlation_matrix, white_noise)
    correlated_noise *= (np.std(values) / np.std(correlated_noise))  # Match scale of noise
    noisy_values = values + correlated_noise
    return np.column_stack((time, noisy_values))

def flip_horizontal(series):
    time, values = extract_time_and_values(series)
    flipped_values = values[::-1]  # Reverse the order of values
    return np.column_stack((time, flipped_values))

# def reverse_time(series):
#     reversed_series = series[::-1]  # Reverse the entire series
#     return reversed_series

def add_slope(series, slope=None):
    time, values = extract_time_and_values(series)
    drift = slope * np.arange(len(values))
    drifted_values = values + drift
    return np.column_stack((time, drifted_values))

def piecewise_scale(series, num_segments=None, scale_range=(None, None)):
    time, values = extract_time_and_values(series)
    segment_size = len(values) // num_segments
    scaled_values = values.copy()
    for i in range(num_segments):
        start = i * segment_size
        end = min((i + 1) * segment_size, len(values))  # Calculate the ending index of the current segment
        scale_factor = np.random.uniform(*scale_range)
        scaled_values[start:end] *= scale_factor
    return np.column_stack((time, scaled_values))

# def inject_trend(series, linear_factor=None, quadratic_factor=None):
#     time, values = extract_time_and_values(series)
#     trend = linear_factor * np.arange(len(values)) + quadratic_factor * (np.arange(len(values)) ** 2)
#     values_with_trend = values + trend
#     return np.column_stack((time, values_with_trend))

def shuffle_sections(series, num_sections=None):
    time, values = extract_time_and_values(series)
    section_size = len(values) // num_sections
    shuffle_indices = np.arange(len(values))
    for i in range(num_sections):
        start = i * section_size
        end = min((i + 1) * section_size, len(values))
        np.random.shuffle(shuffle_indices[start:end])
    shuffled_values = values[shuffle_indices]
    return np.column_stack((time, shuffled_values))

# Main augment function
def augment(series):
    """Apply one random augmentation to the 2D series and return the augmented series and function name."""
    augmentations = {
        'jitter': jitter,
        'time_warp': time_warp,
        # 'time_shift': time_shift,
        'magnitude_scale': magnitude_scale,
        'perturb_fourier': perturb_fourier,
        'add_correlated_noise': add_correlated_noise,
        'flip_horizontal': flip_horizontal,
        # 'reverse_time': reverse_time,
        'add_slope': add_slope,
        'piecewise_scale': piecewise_scale,
        # 'inject_trend': inject_trend,
        'shuffle_sections': shuffle_sections
    }
    
    # Select a random augmentation
    selected_name = random.choice(list(augmentations.keys()))
    selected_augmentation = augmentations[selected_name]

    # Apply the selected augmentation
    if selected_name == 'jitter':
        augmented_series = selected_augmentation(series, sigma=0.001)
    elif selected_name == 'time_warp':
        augmented_series = selected_augmentation(series, sigma=0.8)
    elif selected_name == 'time_shift':
        augmented_series = selected_augmentation(series, max_shift=10)
    elif selected_name == 'magnitude_scale':
        augmented_series = selected_augmentation(series, sigma=0.8)
    elif selected_name == 'perturb_fourier':
        augmented_series = selected_augmentation(series, sigma=0.5)
    elif selected_name == 'add_correlated_noise':
        augmented_series = selected_augmentation(series, correlation_scale=0.2, noise_strength=0.5)
    elif selected_name == 'add_slope':
        augmented_series = selected_augmentation(series, slope=0.0001)
    elif selected_name == 'piecewise_scale':
        augmented_series = selected_augmentation(series, num_segments=20, scale_range=(0.9, 1.1))
    elif selected_name == 'inject_trend':
        augmented_series = selected_augmentation(series, linear_factor=0.05, quadratic_factor=0.1)
    elif selected_name == 'shuffle_sections':
        augmented_series = selected_augmentation(series, num_sections=50)
    else:
        augmented_series = selected_augmentation(series)

    # Return the augmented series and the augmentation name
    return augmented_series, selected_name
