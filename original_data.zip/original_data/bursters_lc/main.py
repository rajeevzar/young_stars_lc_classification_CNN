import os
import numpy as np
from make_wavelet import plot_wavelet_diagram

def read_light_curve(file_path):
    """
    Read a light curve from a .dat file.
    Assumes the file has two columns: timestamps and intensities.
    """
    data = np.loadtxt(file_path)  # Load data from file
    timestamps = data[:, 0]  # First column: time
    light_curve = data[:, 1]  # Second column: intensity
    return timestamps, light_curve

def main():
    # Path to the data file
    star = "EPIC211104793"
    file_name = star+".dat"
    file_path = os.path.join(file_name)

    # Check if the file exists
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return

    # Read the light curve
    timestamps, light_curve = read_light_curve(file_path)

    # Plot the wavelet diagram
    plot_wavelet_diagram(light_curve, timestamps)

if __name__ == "__main__":
    main()